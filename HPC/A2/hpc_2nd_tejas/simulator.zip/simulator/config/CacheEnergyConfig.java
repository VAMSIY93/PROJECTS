package config;

public class CacheEnergyConfig {
	public double leakageEnergy;
	public double readDynamicEnergy;
	public double writeDynamicEnergy;
}
