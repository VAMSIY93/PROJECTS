

public class ReplayEntry
{
	LSQEntry lsEntry;
	int token;

	public int getToken()
	{
		return token;
	}

	public void setToken(int token)
	{
		this.token=token;
	}

}