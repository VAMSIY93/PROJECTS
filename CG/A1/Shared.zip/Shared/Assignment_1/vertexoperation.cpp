#include "vertexoperation.h"

#include <iostream>
using namespace std;

VertexOperation::VertexOperation()
{
}

QVector3D VertexOperation::findNormal(QVector3D r)
{
    float theta = qAcos(r.x() / (qSqrt(r.x()*r.x() + r.y()*r.y())));
    float psi = qAcos(r.z() / (qSqrt(r.x()*r.x() + r.y()*r.y() + r.z()*r.z())));

//    // Convert to degree
//    cout << theta * 180 / M_PI << endl;
//    cout << psi * 180 / M_PI << endl;

    QVector3D n;
    n.setX(qSin(psi) * qCos(theta));
    n.setY(qSin(psi) * qSin(theta));
    n.setZ(qCos(psi));

    return n;
}

QVector3D VertexOperation::findUpVector(QVector3D up, QVector3D n)
{
    QVector3D up_dash = up - (n * (QVector3D::dotProduct(up, n)));
    return up_dash/(qSqrt(up_dash.x()*up_dash.x()+up_dash.y()*up_dash.y()+up_dash.z()*up_dash.z()));
}

QVector3D VertexOperation::crossProduct(QVector3D n, QVector3D v)
{
    return QVector3D::crossProduct(n, v);
}
