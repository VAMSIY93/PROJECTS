#ifndef OPENGLWIDGET_H
#define OPENGLWIDGET_H

#include "vertexoperation.h"

#include <iostream>
#include <fstream>

#include <GL/glut.h>
#include <QVector3D>
#include <QGLWidget>

using namespace std;

class OpenGLWidget : public QGLWidget
{
    Q_OBJECT

    public:
        OpenGLWidget(QWidget *parent = 0);
        ~OpenGLWidget();

        void setPosition(QVector3D, qreal);
//        QSize minimumSize() const;
//        QSize maximumSize() const;

     public slots:
        void setEyeX(double);
        void setEyeY(double);
        void setEyeZ(double);

        void setLookAtX(double);
        void setLookAtY(double);
        void setLookAtZ(double);

        void setUpX(double);
        void setUpY(double);
        void setUpZ(double);

        void setNear(int);
        void setFar(int);

        void setHeight(double);
        void setWidth(double);

     protected:
        void initializeGL();
        void paintGL();
        void resizeGL(int width, int height);

    private:
        QVector3D eye, at, up, rotate;
        char file_name[100];
        fstream file;
        int num_objs;
        float ***vertices;
        int *obj_size;
        static const int cord_count = 3;

        qreal near, far;
        qreal height, width;

        QVector3D center;
        qreal translate;
};

#endif // OPENGLWIDGET_H
