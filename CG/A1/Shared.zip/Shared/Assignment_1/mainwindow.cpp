#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "openglwidget.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    center.setX(0);
    center.setY(0);
    center.setZ(0);

    translate = 0;

    opengl = new OpenGLWidget;
    opengl->setPosition(center, translate);

//    opengl->setMaximumSize(500, 500);
//    opengl->setMinimumSize(500, 500);

    viewer = new Viewer;
    viewer->setPosition(center, translate);

    ui->viewport_graphics->addWidget(opengl);
    ui->layout_graphics->addWidget(viewer);

//    ui->layout_graphics->addLayout(&og);

    connect(ui->sb_eye_x, SIGNAL(valueChanged(double)), opengl, SLOT(setEyeX(double)));
    connect(ui->sb_eye_y, SIGNAL(valueChanged(double)), opengl, SLOT(setEyeY(double)));
    connect(ui->sb_eye_z, SIGNAL(valueChanged(double)), opengl, SLOT(setEyeZ(double)));

    connect(ui->sb_at_x, SIGNAL(valueChanged(double)), opengl, SLOT(setLookAtX(double)));
    connect(ui->sb_at_y, SIGNAL(valueChanged(double)), opengl, SLOT(setLookAtY(double)));
    connect(ui->sb_at_z, SIGNAL(valueChanged(double)), opengl, SLOT(setLookAtZ(double)));

    connect(ui->sb_up_x, SIGNAL(valueChanged(double)), opengl, SLOT(setUpX(double)));
    connect(ui->sb_up_y, SIGNAL(valueChanged(double)), opengl, SLOT(setUpY(double)));
    connect(ui->sb_up_z, SIGNAL(valueChanged(double)), opengl, SLOT(setUpZ(double)));

    connect(ui->sb_near, SIGNAL(valueChanged(int)), opengl, SLOT(setNear(int)));
    connect(ui->sb_far, SIGNAL(valueChanged(int)), opengl, SLOT(setFar(int)));

    connect(ui->sb_height, SIGNAL(valueChanged(double)), opengl, SLOT(setHeight(double)));
    connect(ui->sb_width, SIGNAL(valueChanged(double)), opengl, SLOT(setWidth(double)));

    connect(ui->sb_height, SIGNAL(valueChanged(double)), this, SLOT(setHeight(double)));
    connect(ui->sb_width, SIGNAL(valueChanged(double)), this, SLOT(setWidth(double)));

    connect(ui->sb_eye_x, SIGNAL(valueChanged(double)), viewer, SLOT(setEyeX(double)));
    connect(ui->sb_eye_y, SIGNAL(valueChanged(double)), viewer, SLOT(setEyeY(double)));
    connect(ui->sb_eye_z, SIGNAL(valueChanged(double)), viewer, SLOT(setEyeZ(double)));

    connect(ui->sb_at_x, SIGNAL(valueChanged(double)), viewer, SLOT(setLookAtX(double)));
    connect(ui->sb_at_y, SIGNAL(valueChanged(double)), viewer, SLOT(setLookAtY(double)));
    connect(ui->sb_at_z, SIGNAL(valueChanged(double)), viewer, SLOT(setLookAtZ(double)));

    connect(ui->sb_up_x, SIGNAL(valueChanged(double)), viewer, SLOT(setUpX(double)));
    connect(ui->sb_up_y, SIGNAL(valueChanged(double)), viewer, SLOT(setUpY(double)));
    connect(ui->sb_up_z, SIGNAL(valueChanged(double)), viewer, SLOT(setUpZ(double)));

    connect(ui->sb_near, SIGNAL(valueChanged(int)), viewer, SLOT(setNear(int)));
    connect(ui->sb_far, SIGNAL(valueChanged(int)), viewer, SLOT(setFar(int)));

    connect(ui->sb_height, SIGNAL(valueChanged(double)), viewer, SLOT(setHeight(double)));
    connect(ui->sb_width, SIGNAL(valueChanged(double)), viewer, SLOT(setWidth(double)));

    connect(ui->btn_frustrum, SIGNAL(clicked()), viewer, SLOT(frustrumView()));
    connect(ui->btn_perspective, SIGNAL(clicked()), viewer, SLOT(perspectiveView()));
    connect(ui->btn_normalization, SIGNAL(clicked()), viewer, SLOT(normalizedView()));
    connect(ui->btn_clipped, SIGNAL(clicked()), viewer, SLOT(clippedView()));

    connect(ui->btn_frustrum, SIGNAL(clicked()), this, SLOT(setFrustum()));
    connect(ui->btn_perspective, SIGNAL(clicked()), this, SLOT(setPerspective()));
    connect(ui->btn_normalization, SIGNAL(clicked()), this, SLOT(setNormalize()));
    connect(ui->btn_clipped, SIGNAL(clicked()), this, SLOT(setClipping()));

    ui->sb_eye_x->setValue(0);
    ui->sb_eye_y->setValue(0);
    ui->sb_eye_z->setValue(-3);

    ui->sb_at_x->setValue(0.75);
    ui->sb_at_y->setValue(0.75);
    ui->sb_at_z->setValue(0.75);

    ui->sb_up_x->setValue(0);
    ui->sb_up_y->setValue(1);
    ui->sb_up_z->setValue(0);

    ui->sb_near->setValue(25);
    ui->sb_far->setValue(25);

    ui->sb_height->setValue(1);
    ui->sb_width->setValue(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setHeight(double val)
{
    opengl->setMaximumHeight(val*500);
    opengl->setMinimumHeight(val*500);
}


void MainWindow::setWidth(double val)
{
    opengl->setMaximumWidth(val*500);
    opengl->setMinimumWidth(val*500);
}

void MainWindow::setPerspective()
{
    ui->current_view->setText("Perspective view");
}


void MainWindow::setNormalize()
{
    ui->current_view->setText("Normalized view");
}

void MainWindow::setClipping()
{
    ui->current_view->setText("Clipped view");
}

void MainWindow::setFrustum()
{
    ui->current_view->setText("Frustum view");
}
