#ifndef VERTEXOPERATION_H
#define VERTEXOPERATION_H

#include <QLineF>
#include <QVector3D>
#include <QtCore/qmath.h>

#include <math.h>

class VertexOperation
{
public:
    VertexOperation();

    static QVector3D findNormal(QVector3D);
    static QVector3D findUpVector(QVector3D, QVector3D);
    static QVector3D crossProduct(QVector3D, QVector3D);
};

#endif // VERTEXOPERATION_H
