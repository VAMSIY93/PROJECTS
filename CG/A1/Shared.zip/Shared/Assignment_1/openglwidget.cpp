#include "openglwidget.h"

OpenGLWidget::OpenGLWidget(QWidget *parent) : QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
    strcpy(file_name, "object1");

    file.open(file_name, ios::in);

    if (file.is_open())
    {
        file >> num_objs;

        vertices = new float**[num_objs];
        obj_size = new int[num_objs];

        for(int i = 0; i < num_objs; i++)
        {
            file >> obj_size[i];

            vertices[i] = new float*[obj_size[i]];

            for(int j = 0; j < obj_size[i]; j++)
            {
                vertices[i][j] = new float[cord_count];

                for(int k = 0; k < cord_count; k++)
                {
                    file >> vertices[i][j][k];
                }
            }
        }

        file.close();
    }
    else
    {
        cerr << "Unable to open file" << endl;
    }
}

OpenGLWidget::~OpenGLWidget()
{

}

void OpenGLWidget::setPosition(QVector3D c, qreal t)
{
    center = c;
    translate = t;
}

void OpenGLWidget::setEyeX(double val)
{
    eye.setX(val);
    updateGL();
}

void OpenGLWidget::setEyeY(double val)
{
    eye.setY(val);
    updateGL();
}

void OpenGLWidget::setEyeZ(double val)
{
    eye.setZ(val);
    updateGL();
}

void OpenGLWidget::setLookAtX(double val)
{
    at.setX(val);
    updateGL();
}

void OpenGLWidget::setLookAtY(double val)
{
    at.setY(val);
    updateGL();
}

void OpenGLWidget::setLookAtZ(double val)
{
    at.setZ(val);
    updateGL();
}

void OpenGLWidget::setUpX(double val)
{
    up.setX(val);
    updateGL();
}

void OpenGLWidget::setUpY(double val)
{
    up.setY(val);
    updateGL();
}

void OpenGLWidget::setUpZ(double val)
{
    up.setZ(val);
    updateGL();
}

void OpenGLWidget::setNear(int val)
{
    near = 1 - val / 100.0;
    updateGL();
}

void OpenGLWidget::setFar(int val)
{
    far = 1 + val / 100.0;
    updateGL();
}

void OpenGLWidget::setHeight(double val)
{
    height = val;
    cout << height << endl;

    updateGL();
}

void OpenGLWidget::setWidth(double val)
{
    width = val;
    cout << width << endl;
    updateGL();
}

void OpenGLWidget::initializeGL()
{
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glEnable(GL_DEPTH_TEST);
}

void OpenGLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    QVector3D n = VertexOperation::findNormal(at);

    gluLookAt(eye.x(), eye.y(), 3/.58 * -n.z() + eye.z(), at.x()-0.75, at.y()-0.75, at.z()-0.75, up.x(), up.y(), up.z());
//    glRotatef(rotate.x(), 1.0f, 0.0f, 0.0f);
//    glRotatef(rotate.y(), 0.0f, 1.0f, 0.0f);
//    glRotatef(rotate.z(), 0.0f, 0.0f, 1.0f);

        for(int i = 0; i < num_objs; i++)
        {
            glColor3f(0.75, 0.75, 1.0 / (i + 1));

            glBegin(GL_LINE_STRIP);
            for(int j = 0; j < obj_size[i]; j++)
            {
                QVector3D vertex(vertices[i][j][0], vertices[i][j][1], vertices[i][j][2]);
                glVertex3f(vertex.x(), vertex.y(), vertex.z());
            }
            glEnd();
        }

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        glFrustum(-1.0, 1.0, -1.0, 1.0, (near) * (eye.z()+3), (far) * (eye.z()+3));

        glMatrixMode(GL_MODELVIEW);

    glFlush();
    swapBuffers();
}

void OpenGLWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, 500, 500);
    w = w;
    h = h;

    if (!height)
    {
        height = 1.0;
    }

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glFrustum(-1.0, 1.0, -1.0, 1.0, (near) * (eye.z()+3), (far) * (eye.z()+3));

    glMatrixMode(GL_MODELVIEW);
}
