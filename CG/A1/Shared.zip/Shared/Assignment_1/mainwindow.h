#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "openglwidget.h"
#include "viewer.h"

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    OpenGLWidget *opengl;
    Viewer *viewer;

    QVector3D center;
    qreal translate;

public slots:
    void setWidth(double);
    void setHeight(double);

private slots:
    void setPerspective();
    void setNormalize();
    void setClipping();
    void setFrustum();
};

#endif // MAINWINDOW_H
