#include "viewer.h"

Viewer::Viewer(QWidget *parent) : QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
    strcpy(file_name, "object1");

    file.open(file_name, ios::in);

    if (file.is_open())
    {
        file >> num_objs;

        vertices = new float**[num_objs];
        obj_size = new int[num_objs];

        for(int i = 0; i < num_objs; i++)
        {
            file >> obj_size[i];

            vertices[i] = new float*[obj_size[i]];

            for(int j = 0; j < obj_size[i]; j++)
            {
                vertices[i][j] = new float[cord_count];

                for(int k = 0; k < cord_count; k++)
                {
                    file >> vertices[i][j][k];
                }
            }
        }

        file.close();
    }
    else
    {
        cerr << "Unable to open file" << endl;
    }

    //    displayVertices();
    //    up.setX(0);
    //    up.setY(1);
    //    up.setZ(0);

    display_mode = 2;
}

Viewer::~Viewer()
{

}

void Viewer::setPosition(QVector3D c, qreal t)
{
    center = c;
    translate = t;
}

void Viewer::displayVertices()
{
    for(int i = 0; i < num_objs; i++)
    {
        for(int j = 0; j < obj_size[i]; j++)
        {
            for(int k = 0; k < cord_count; k++)
            {
                cout << vertices[i][j][k] << " ";
            }

            cout << endl;
        }

        cout << endl;
    }
}

void Viewer::setEyeX(double val)
{
    eye.setX(val);
    updateGL();
}

void Viewer::setEyeY(double val)
{
    eye.setY(val);
    updateGL();
}

void Viewer::setEyeZ(double val)
{
    eye.setZ(val);
    updateGL();
}

void Viewer::setLookAtX(double val)
{
    at.setX(val);
    updateGL();
}

void Viewer::setLookAtY(double val)
{
    at.setY(val);
    updateGL();
}

void Viewer::setLookAtZ(double val)
{
    at.setZ(val);
    updateGL();
}

void Viewer::setUpX(double val)
{
    up.setX(val);
    updateGL();
}

void Viewer::setUpY(double val)
{
    up.setY(val);
    updateGL();
}

void Viewer::setUpZ(double val)
{
    up.setZ(val);
    updateGL();
}

void Viewer::setNear(int val)
{
    near = 1 - val / 100.0;
    updateGL();
}

void Viewer::setFar(int val)
{
    far = 1 + val / 100.0;
    updateGL();
}

void Viewer::setHeight(double val)
{
    height = val;
    updateGL();
}

void Viewer::setWidth(double val)
{
    width = val;
    updateGL();
}

void Viewer::perspectiveView()
{
    display_mode = 1;
    updateGL();
}

void Viewer::frustrumView()
{
    display_mode = 2;
    updateGL();
}

void Viewer::normalizedView()
{
    display_mode = 3;
    updateGL();
}

void Viewer::clippedView()
{
    display_mode = 4;
    updateGL();
}

void Viewer::initializeGL()
{
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
}

void Viewer::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    n = VertexOperation::findNormal(at);
    v = VertexOperation::findUpVector(up, n);
    u = VertexOperation::crossProduct(n, v);

        printVertex(n);
        printVertex(v);
        printVertex(u);

    gluLookAt(0.0, 0.0, -3.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    glBegin(GL_LINES);
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(0, 0, 0);
    glVertex3f(n.x(), n.y(), n.z());

    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0, 0, 0);
    glVertex3f(v.x(), v.y(), v.z());

    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0, 0, 0);
    glVertex3f(u.x(), u.y(), u.z());
    glEnd();

    QVector3D w1, w2, w3, w4;

    viewport[0] = setVertex(center.x() - width / 2 - translate, center.y() - height / 2 - translate, 0);
    viewport[1] = setVertex(center.x() - width / 2 - translate, center.y() + height / 2 - translate, 0);
    viewport[2] = setVertex(center.x() + width / 2 - translate, center.y() + height / 2 - translate, 0);
    viewport[3] = setVertex(center.x() + width / 2 - translate, center.y() - height / 2 - translate, 0);

    w1 = transformToVCS(viewport[0]);
    w2 = transformToVCS(viewport[1]);
    w3 = transformToVCS(viewport[2]);
    w4 = transformToVCS(viewport[3]);

    if(display_mode == 2)
    {
    //    // Draw Viewport plane
        glBegin(GL_LINE_LOOP);
        glColor4f(1.0, 1.0, 1.0, 0.0);
        glVertex3f(w1.x(), w1.y(), w1.z());
        glVertex3f(w2.x(), w2.y(), w2.z());
        glVertex3f(w3.x(), w3.y(), w3.z());
        glVertex3f(w4.x(), w4.y(), w4.z());
        glEnd();
    }

    if(display_mode == 4)
    {
        QVector3D vp1, vp2, vp3, vp4;

//        vp1 = extendPort(viewport[0]);
//        vp2 = extendPort(viewport[1]);
//        vp3 = extendPort(viewport[2]);
//        vp4 = extendPort(viewport[3]);

        qreal w = width + 0.25, h = height + 0.2;

        vp1 = setVertex(center.x() - w / 2 - translate, center.y() - h / 2 - translate, 0);
        vp2 = setVertex(center.x() - w / 2 - translate, center.y() + h / 2 - translate, 0);
        vp3 = setVertex(center.x() + w / 2 - translate, center.y() + h / 2 - translate, 0);
        vp4 = setVertex(center.x() + w / 2 - translate, center.y() - h / 2 - translate, 0);

        vp1 = rotateViewport(vp1);
        vp2 = rotateViewport(vp2);
        vp3 = rotateViewport(vp3);
        vp4 = rotateViewport(vp4);

        glBegin(GL_LINE_LOOP);
        glColor4f(1.0, 1.0, 1.0, 0.0);
        glVertex3f(vp1.x(), vp1.y(), vp1.z());
        glVertex3f(vp2.x(), vp2.y(), vp2.z());
        glVertex3f(vp3.x(), vp3.y(), vp3.z());
        glVertex3f(vp4.x(), vp4.y(), vp4.z());
        glEnd();

        for(int j = 0; j < num_objs; j++)
        {
            glColor3f(1, 1, 1);
            float **clipped;

            clipped = new float*[(obj_size[j] - 1)];

            glBegin(GL_LINES);
            glColor3f(0.75, 0.75, 1.0 / (j + 1));
            for(int i = 0; i < obj_size[j] -1; i++)
            {
                clipped[i] = new float[6];
                clipped[i] = clipCube(vertices[j][i][0], vertices[j][i][1], vertices[j][i][2], vertices[j][i+1][0], vertices[j][i+1][1], vertices[j][i+1][2], viewport[0].x(), viewport[2].x(), viewport[0].y(), viewport[2].y(), -(1-near)*3, (far-1)*3);
                if(clipped[i] != NULL)
                {
                    QVector3D pt1(clipped[i][0], clipped[i][1], clipped[i][2]), pt2(clipped[i][3], clipped[i][4], clipped[i][5]);
                    QVector3D point1, point2;

                    point1 = transformToVCS(pt1);
                    point2 = transformToVCS(pt2);

                    glVertex3f(point1.x(), point1.y(), point1.z());
                    glVertex3f(point2.x(), point2.y(), point2.z());

                    point1 = convertTo2D(pt1);
                    point2 = convertTo2D(pt2);

                    point1 = rotateViewport(point1);
                    point2 = rotateViewport(point2);

                    glVertex3f(point1.x(), point1.y(), point1.z());
                    glVertex3f(point2.x(), point2.y(), point2.z());

                 }
            }

            glEnd();
        }


    }

    // Draw camera
    glBegin(GL_TRIANGLES);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-n.x(), -n.y(), eye.z()-n.z());
    glVertex3f(-n.x()-0.01,  -n.y() -0.04, eye.z()-n.z());
    glVertex3f(-n.x()+0.01,  -n.y() - 0.04, eye.z()-n.z());
    glEnd();

    if(display_mode == 1 || display_mode == 4)
    {
        QVector3D v1 = viewport[0];
        QVector3D v2 = viewport[1];
        QVector3D v3 = viewport[2];
        QVector3D v4 = viewport[3];

        v1.setZ(2*(near-1)*(n.z()));
        v2.setZ(2*(near-1)*(n.z()));
        v3.setZ(2*(near-1)*(n.z()));
        v4.setZ(2*(near-1)*(n.z()));

        v1 = transformToVCS(v1);
        v2 = transformToVCS(v2);
        v3 = transformToVCS(v3);
        v4 = transformToVCS(v4);

        // Draw near face
        glBegin(GL_LINE_LOOP);
        glColor4f(0.0, 1.0, 0.0, 0.0);
        glVertex3f(v1.x(), v1.y(), v1.z());
        glVertex3f(v2.x(), v2.y(), v2.z());
        glVertex3f(v3.x(), v3.y(), v3.z());
        glVertex3f(v4.x(), v4.y(), v4.z());
        glEnd();

        QVector3D vx1 = viewport[0];
        QVector3D vx2 = viewport[1];
        QVector3D vx3 = viewport[2];
        QVector3D vx4 = viewport[3];

        vx1.setZ(2*(far-1)*(n.z()));
        vx2.setZ(2*(far-1)*(n.z()));
        vx3.setZ(2*(far-1)*(n.z()));
        vx4.setZ(2*(far-1)*(n.z()));

        vx1 = transformToVCS(vx1);
        vx2 = transformToVCS(vx2);
        vx3 = transformToVCS(vx3);
        vx4 = transformToVCS(vx4);

        // Draw back face
        glBegin(GL_LINE_LOOP);
        glColor4f(0.0, 1.0, 0.0, 0.0);
        glVertex3f(vx1.x(), vx1.y(), vx1.z());
        glVertex3f(vx2.x(), vx2.y(), vx2.z());
        glVertex3f(vx3.x(), vx3.y(), vx3.z());
        glVertex3f(vx4.x(), vx4.y(), vx4.z());
        glEnd();

        // Compete faces
        glBegin(GL_LINES);
        glColor4f(0.0, 1.0, 0.0, 0.0);
        glVertex3f(v1.x(), v1.y(), v1.z());
        glVertex3f(vx1.x(), vx1.y(), vx1.z());

        glVertex3f(v2.x(), v2.y(), v2.z());
        glVertex3f(vx2.x(), vx2.y(), vx2.z());

        glVertex3f(v3.x(), v3.y(), v3.z());
        glVertex3f(vx3.x(), vx3.y(), vx3.z());

        glVertex3f(v4.x(), v4.y(), v4.z());
        glVertex3f(vx4.x(), vx4.y(), vx4.z());
        glEnd();
    }

    QVector3D p1=w1, p2=w2, p3=w3, p4=w4;

    if(display_mode == 2)
    {
        front_plane[0] = extend(p1, near);
        front_plane[1] = extend(p2, near);
        front_plane[2] = extend(p3, near);
        front_plane[3] = extend(p4, near);

        glBegin(GL_LINE_LOOP);
        glColor3f(0.0, 1, 0.0);
        glVertex3f(front_plane[0].x(), front_plane[0].y(), front_plane[0].z());
        glVertex3f(front_plane[1].x(), front_plane[1].y(), front_plane[1].z());
        glVertex3f(front_plane[2].x(), front_plane[2].y(), front_plane[2].z());
        glVertex3f(front_plane[3].x(), front_plane[3].y(), front_plane[3].z());
        glEnd();
    }

    F = (at.z() - front_plane[0].z());

    if(display_mode == 2)
    {
        back_plane[0] = extend(p1, far);
        back_plane[1] = extend(p2, far);
        back_plane[2] = extend(p3, far);
        back_plane[3] = extend(p4, far);

        glBegin(GL_LINE_LOOP);
        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(back_plane[0].x(), back_plane[0].y(), back_plane[0].z());
        glVertex3f(back_plane[1].x(), back_plane[1].y(), back_plane[1].z());
        glVertex3f(back_plane[2].x(), back_plane[2].y(), back_plane[2].z());
        glVertex3f(back_plane[3].x(), back_plane[3].y(), back_plane[3].z());
        glEnd();
    }

B = at.z() - back_plane[0].z();

QVector3D v1 = viewport[0];
QVector3D v2 = viewport[1];
QVector3D v3 = viewport[2];
QVector3D v4 = viewport[3];

v1.setZ(2*(near-1)*(n.z()));
v2.setZ(2*(near-1)*(n.z()));
v3.setZ(2*(near-1)*(n.z()));
v4.setZ(2*(near-1)*(n.z()));

v1 = normalizeVolume(v1);
v2 = normalizeVolume(v2);
v3 = normalizeVolume(v3);
v4 = normalizeVolume(v4);

v1 = transformToVCS(v1);
v2 = transformToVCS(v2);
v3 = transformToVCS(v3);
v4 = transformToVCS(v4);

QVector3D vx1 = viewport[0];
QVector3D vx2 = viewport[1];
QVector3D vx3 = viewport[2];
QVector3D vx4 = viewport[3];

vx1.setZ(2*(far-1)*(n.z()));
vx2.setZ(2*(far-1)*(n.z()));
vx3.setZ(2*(far-1)*(n.z()));
vx4.setZ(2*(far-1)*(n.z()));

vx1 = normalizeVolume(vx1);
vx2 = normalizeVolume(vx2);
vx3 = normalizeVolume(vx3);
vx4 = normalizeVolume(vx4);

vx1 = transformToVCS(vx1);
vx2 = transformToVCS(vx2);
vx3 = transformToVCS(vx3);
vx4 = transformToVCS(vx4);


if(display_mode == 3)
{
/*    Normalization step */

    // Draw near face
    glBegin(GL_LINE_LOOP);
    glColor4f(0.0, 1.0, 0.0, 0.0);
    glVertex3f(v1.x(), v1.y(), v1.z());
    glVertex3f(v2.x(), v2.y(), v2.z());
    glVertex3f(v3.x(), v3.y(), v3.z());
    glVertex3f(v4.x(), v4.y(), v4.z());
    glEnd();


    // Draw back face
    glBegin(GL_LINE_LOOP);
    glColor4f(0.0, 1.0, 0.0, 0.0);
    glVertex3f(vx1.x(), vx1.y(), vx1.z());
    glVertex3f(vx2.x(), vx2.y(), vx2.z());
    glVertex3f(vx3.x(), vx3.y(), vx3.z());
    glVertex3f(vx4.x(), vx4.y(), vx4.z());
    glEnd();

    // Compete faces
    glBegin(GL_LINES);
    glColor4f(0.0, 1.0, 0.0, 0.0);
    glVertex3f(v1.x(), v1.y(), v1.z());
    glVertex3f(vx1.x(), vx1.y(), vx1.z());

    glVertex3f(v2.x(), v2.y(), v2.z());
    glVertex3f(vx2.x(), vx2.y(), vx2.z());

    glVertex3f(v3.x(), v3.y(), v3.z());
    glVertex3f(vx3.x(), vx3.y(), vx3.z());

    glVertex3f(v4.x(), v4.y(), v4.z());
    glVertex3f(vx4.x(), vx4.y(), vx4.z());
    glEnd();
}






    // Draw the object in the world coordinate system

    //    for(int i = 0; i < num_objs; i++)
    //    {
    //        glColor3f(0.75, 0.75, 1.0 / (i + 1));

    //        glBegin(GL_LINE_STRIP);
    //        for(int j = 0; j < obj_size[i]; j++)
    //        {
    //            QVector3D vertex(vertices[i][j][0], vertices[i][j][1], vertices[i][j][2]);
    //            vertex = rotateInWCS(vertex);
    //            glVertex3f(vertex.x(), vertex.y(), vertex.z());
    //        }
    //        glEnd();
    //    }

    if(display_mode == 2)
    {
        // Draw the projection lines
        glBegin(GL_LINES);
        glColor3f(0.6, 0.4, 0.6);
        glVertex3f(-n.x(), -n.y(), (eye.z()-n.z()));
        glVertex3f(back_plane[0].x(), back_plane[0].y(), back_plane[0].z());

        glVertex3f(-n.x(), -n.y(), (eye.z()-n.z()));
        glVertex3f(back_plane[1].x(), back_plane[1].y(), back_plane[1].z());

        glVertex3f(-n.x(), -n.y(), (eye.z()-n.z()));
        glVertex3f(back_plane[2].x(), back_plane[2].y(), back_plane[2].z());

        glVertex3f(-n.x(), -n.y(), (eye.z()-n.z()));
        glVertex3f(back_plane[3].x(), back_plane[3].y(), back_plane[3].z());
        glEnd();

    }

    if(display_mode != 4)
    {
        // Draw the values in the plane
        for(int i = 0; i < num_objs; i++)
        {
            glColor3f(0.75, 0.75, 1.0 / (i + 1));

            glBegin(GL_LINE_STRIP);
            for(int j = 0; j < obj_size[i]; j++)
            {
                QVector3D vertex(vertices[i][j][0], vertices[i][j][1], vertices[i][j][2]);

                if(display_mode == 2)
                {
    //                vertex = parallelProjection(vertex, center.x() - width / 2 - translate, center.x() + width / 2, center.y() - height / 2, center.y() + height / 2);
                                vertex = projectOnViewPlane(vertex);
                }
                else if(display_mode == 3)
                {
                    vertex = normalizeVolume(vertex);
                }

                vertex = transformToVCS(vertex);

                glVertex3f(vertex.x(), vertex.y(), vertex.z());
            }
            glEnd();
        }
    }

    glFlush();
    swapBuffers();
}

void Viewer::resizeGL(int width, int height)
{
    glViewport(0, 0, width, height);

    if (!height)
    {
        height = 1.0;
    }

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glFrustum(-1.0f, 1.0f, -1.0f, 1.0f, 2.0f, 20.0f);
    //    gluPerspective(45.0f, (GLfloat) width / (GLfloat) height, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);
}

void Viewer::printVertex(QVector3D v)
{
    cout << v.x() << " " << v.y()
         << " " << v.z() << endl;

    //    cout << "Slope: " << (v.z()) / qSqrt(((v.x()) * (v.x())) + ((v.y()) * (v.y()))) << endl;
    //    cout << "Slope: " << (at.z() - v.z()) / qSqrt(((v.x() - at.x()) * (v.x() - at.x())) + ((v.y() - at.y()) * (v.y() - at.y()))) << endl;
}

QVector3D Viewer::transformToVCS(QVector3D vertex)
{
    float t1 = vertex.x() * u.x() + vertex.y() * v.x() + vertex.z() * n.x() + at.x();
    float t2 = vertex.x() * u.y() + vertex.y() * v.y() + vertex.z() * n.y() + at.y();
    float t3;

    if(display_mode == 2)
    {
        t3 = vertex.x() * u.z() + vertex.y() * v.z() + vertex.z() * (n.z()-eye.z()) + at.z();
    }
    else
    {
        t3 = vertex.x() * u.z() + vertex.y() * v.z() + vertex.z() * n.z() + at.z();
    }

    QVector3D vec(t1, t2, t3);

    return vec;
}

QVector3D Viewer::rotateViewport(QVector3D vertex)
{
    float t1 = vertex.x() * u.x() + vertex.y() * v.x() + vertex.z() * n.x();
    float t2 = vertex.x() * u.y() + vertex.y() * v.y() + vertex.z() * n.y();
    float t3 = vertex.x() * u.z() + vertex.y() * v.z() + vertex.z() * n.z();

    QVector3D vec(t1, t2, t3);

    return vec;
}

QVector3D Viewer::projectOnViewPlane(QVector3D vertex)
{
    float w = 1 - vertex.z() / (n.z()-eye.z());

    float t1 = vertex.x() / w;
    float t2 = vertex.y() / w;
    float t3 = vertex.z() / w;

    QVector3D vec(t1, t2, t3);

    return vec;
}

QVector3D Viewer::rotateInWCS(QVector3D vertex)
{
    float t1 = vertex.x() * u.x() + vertex.y() * v.x() + vertex.z() * n.x();
    float t2 = vertex.x() * u.y() + vertex.y() * v.y() + vertex.z() * n.y();
    float t3 = vertex.x() * u.z() + vertex.y() * v.z() + vertex.z() * (n.z()-eye.z());

    QVector3D vec(t1, t2, t3);

    return vec;
}

QVector3D Viewer::extend(QVector3D p, qreal t)
{
    QVector3D w;

    w.setX(-n.x()+(p.x()-(-n.x()))*t);
    w.setY(-n.y()+(p.y()-(-n.y()))*t);
    w.setZ((eye.z()-n.z())+(p.z()-((eye.z()-n.z())))*t);

    return w;
}

QVector3D Viewer::parallelProjection(QVector3D vertex, qreal l, qreal r, qreal t, qreal b)
{
    QVector3D res;
    qreal n = -near*at.z();
    qreal f = far*at.z();

    qreal x = vertex.x() * 2 * (n) / (r-l);
    qreal y = vertex.y() * 2 * (n) / (t-b);
    qreal z = (vertex.x() * (r + l) / (r - l)) + (vertex.y() * (b + t) / (t-b)) + (vertex.z() * ((f+n)/(n-f))) - 1;
    //    qreal x = vertex.x();
    //    qreal y = vertex.y();
    //    qreal z = vertex.z();
    qreal w = vertex.z() * (2 * (n*f)) / (n-f);

    res.setX(x/w);
    res.setY(y/w);
    res.setZ(z/w);

    return res;
}

QVector3D Viewer::setVertex(qreal x, qreal y, qreal z)
{
    QVector3D res(x, y, z);
    return res;
}

QVector3D Viewer::normalizeVolume(QVector3D vec)
{
    QVector3D res;

    qreal wl = viewport[0].x(), wr = viewport[2].x(), wt = viewport[2].y(), wb = viewport[0].y();
    qreal vl = 0, vr = 1.05, vt = 1.05, vb = 0;
    qreal en;

//    F = 2*(near-1)*n.z();
//    B = 2*(far-1)*n.z();
//    F = front_plane[0].z()+n.z();
//    B = back_plane[0].z() + n.z();

//    QVector3D front_plane[3], back_plane[3];

//    front_plane[0] = extend(transformToVCS(viewport[0]), near);
//    front_plane[1] = extend(transformToVCS(viewport[1]), near);
//    front_plane[2] = extend(transformToVCS(viewport[2]), near);

//    back_plane[0] = extend(transformToVCS(viewport[0]), far);
//    back_plane[1] = extend(transformToVCS(viewport[1]), far);
//    back_plane[2] = extend(transformToVCS(viewport[2]), far);


    qreal x = (- at.x());
    qreal y = (- at.y());
    qreal z = ( - at.z());
//    cout << "BP FROM VRP "  << qSqrt(x*x+y*y+z*z) << endl;

//    x = ((front_plane[0].x() + front_plane[1].x()) / 2 - n.x());
//    y = ((front_plane[2].y() + front_plane[1].y()) / 2 - n.y());
//    z = (front_plane[0].z() - n.z());
//    F = qSqrt(x*x+y*y+z*z);

//    x = ((back_plane[0].x() + back_plane[1].x()) / 2 - n.x());
//    y = ((back_plane[2].y() + back_plane[1].y()) / 2 - n.y());
//    z = (back_plane[0].z() - n.z());
//    B = qSqrt(x*x+y*y+z*z);

    qreal dist = qSqrt(x*x+y*y+z*z);

    F = (dist + (n.z()-eye.z())) * (near);
    B = (dist + (n.z()-eye.z())) * (far);
    en = dist + (n.z()-eye.z());
//    cout << front_plane[0].z() << " " << back_plane[0].z() << endl;
//    cout << F << " " << B << endl;

    qreal su = 1, sv = 1, sn = 1;
    qreal ru, rv, rn;

    su=(vl-vr)/(wl-wr);
    sv=(vt-vb)/(wt-wb);
    sn=((en-B)*(en-F))/(en*en*(F-B));

    sn = 1;
//    cout << wl << " " << wr << " " << wt << " " << wb << endl;
//    cout << su << " " << sv << " " << " " << sn << endl;
ru=(vr*wl-vl*wr)/(wl-wr);
rv=(vb*wt-vt*wb)/(wt-wb);
rn=F*(en-B)/en*(F-B);

ru = rv = rn = 0;

    res.setX(vec.x()*su+ru);
    res.setY(vec.y()*sv+rv);
    res.setZ(vec.z()*sn+rn);

    return res;
}

float * Viewer::clipCube(float x1, float y1, float z1, float x2, float y2, float z2, float xmin, float xmax, float ymin, float ymax, float zmin, float zmax)
{
    float u1 = 0, u2=1;
    float p[6], q[6];
    float *res = new float[6];

    p[1] = (x2-x1);
    p[0] = -p[1];
    p[3] = (y2-y1);
    p[2] = -p[3];
    p[5] = (z2-z1);
    p[4] = -p[5];

    q[0] = (x1-xmin);
    q[1] = (xmax-x1);
    q[2] = (y1-ymin);
    q[3] = (ymax-y1);
    q[4] = (z1-zmin);
    q[5] = (zmax-z1);

    for(int k = 0; k < 6; k++)
    {
        if(p[k] == 0)
        {
            if(q[k] < 0)
            {
                return NULL;
            }
        }
        else if(p[k] < 0)
        {
            u1 = max(u1, q[k]/p[k]);
        }
        else
        {
            u2 = min(u2, q[k]/p[k]);
        }
    }

    if(u1 > u2)
    {
        return NULL;                    // Trivially reject
    }

    res[0] = x1 + u1*(x2-x1);
    res[1] = y1 + u1*(y2-y1);
    res[2] = z1 + u1*(z2-z1);

    res[3] = x1 + u2*(x2-x1);
    res[4] = y1 + u2*(y2-y1);
    res[5] = z1 + u2*(z2-z1);

    return res;
}

//double Viewer::getEyePos()
//{
//    QVector3D n = VertexOperation::findNormal(at);
//    return -n.z()+eye.z();
//}

QVector3D Viewer::convertTo2D(QVector3D vertex)
{
    QVector3D res(n.z()*vertex.x()/(n.z()-vertex.z()), n.z()*vertex.y()/(n.z()-vertex.z()), 0);

    return res;
}

QVector3D Viewer::extendPort(QVector3D v)
{
    QVector3D res(v.x() + 0.2, v.y() + 0.2, v.z());
    return res;
}
