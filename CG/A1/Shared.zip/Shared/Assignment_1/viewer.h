#ifndef VIEWER_H
#define VIEWER_H

#include "vertexoperation.h"

#include <fstream>
#include <string>
#include <cstring>
#include <iostream>
#include <cstdlib>

#include <QGLWidget>
#include <QVector3D>
#include <GL/glut.h>

using namespace std;

class Viewer : public QGLWidget
{
   Q_OBJECT

public:
    Viewer(QWidget *parent = 0);
    ~Viewer();

    void setPosition(QVector3D, qreal);
    double getEyePos();

public slots:
    void setEyeX(double);
    void setEyeY(double);
    void setEyeZ(double);

    void setLookAtX(double);
    void setLookAtY(double);
    void setLookAtZ(double);

    void setUpX(double);
    void setUpY(double);
    void setUpZ(double);

    void setNear(int);
    void setFar(int);

    void setHeight(double);
    void setWidth(double);

    void perspectiveView();
    void frustrumView();
    void normalizedView();
    void clippedView();

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);

private:
    char file_name[100];
    fstream file;
    int num_objs;
    float ***vertices;
    int *obj_size;
    static const int cord_count = 3;

    int display_mode;

    QVector3D eye, at, up;
    QVector3D u, v, n;
    QVector3D viewport[4], front_plane[4], back_plane[4];
    qreal near, far;
    qreal height, width;
    qreal F, B;

    QVector3D center;
    qreal translate;

    void displayVertices();
    void printVertex(QVector3D);

    QVector3D setVertex(qreal, qreal, qreal);
    QVector3D transformToVCS(QVector3D);
    QVector3D projectOnViewPlane(QVector3D);
    QVector3D rotateInWCS(QVector3D);
    QVector3D extend(QVector3D p, qreal t);
    QVector3D parallelProjection(QVector3D, qreal, qreal, qreal, qreal);
    QVector3D normalizeVolume(QVector3D);
    QVector3D rotateViewport(QVector3D vertex);
    QVector3D convertTo2D(QVector3D vertex);
    QVector3D extendPort(QVector3D v);
    float * clipCube(float x1, float y1, float z1, float x2, float y2, float z2, float xmin, float xmax, float ymin, float ymax, float zmin, float zmax);


};

#endif // VIEWER_H
