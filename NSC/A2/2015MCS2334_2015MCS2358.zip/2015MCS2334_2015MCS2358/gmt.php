<html>
<head>
<style>
body {background-color: LightGrey;}
h1   {color: LightSeaGreen;}
a    {color: blue;}
</style>
<h1 align="center">SECURED GMT</h1>
</head>
<body bgcolor="LightGrey">
<a href = "server.php"><p style="text-align:center">FETCH CURRENT GMT DATE AND TIME</p></a>
</body>
</html>
